  ______      __                  _     __           __  
 /_  __/___ _/ /_____ _____ ___  (_)___/ /___  _____/ /__
  / / / __ `/ __/ __ `/ __ `__ \/ / __  / __ \/ ___/ //_/
 / / / /_/ / /_/ /_/ / / / / / / / /_/ / /_/ / /  / ,<   
/_/  \__,_/\__/\__,_/_/ /_/ /_/_/\__,_/\____/_/  /_/|_|  
                                                         

Thank you for downloading!

Pixel Art Wallpaper Pack

High-resolution pixel art wallpapers, available in both animated and static versions, for smartphones.
Perfect for home screen or lock screen use.

Includes:

Animated phone wallpaper (MP4)
Static wallpaper (PNG)

Optimized for tall screens (19.5:9 and similar aspect ratios)

Dimensions:

Android: 1600 × 3200 px
iPhone: 1200 × 2598 px

Pixel-perfect scaling (no blur)

iPhone users:

iOS does not support animated wallpapers directly.
To use the animated versions, convert the video into a Live Photo using a free app like intoLive, then set it as your wallpaper.

Static wallpapers (PNG) can be used directly from the photo gallery.

Android users:

Most Android devices support video wallpapers either natively or through free apps.
A simple option is Wallpaper Engine: open the app, select the MP4 file, and set it as your wallpaper in seconds.

Static wallpapers (PNG) work natively on any device.

Important notes:

-Files are intended for wallpaper use only
-Redistribution, resale, printing, or modification is not allowed
-Minor cropping may occur depending on device aspect ratio
-Pixel art quality is preserved

Made with care and pixels by

T A T A M I D O R K ™ (2026)


